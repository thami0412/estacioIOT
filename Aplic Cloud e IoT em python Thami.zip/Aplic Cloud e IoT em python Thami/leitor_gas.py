import random
import time
import requests
from datetime import datetime

# Valor inicial do nível de gás (100%)
nivel_gas_atual = 100.0

# URL do endpoint que receberá os dados
endpoint_url = "http://localhost:5000/receber_dados"

# Função para simular a diminuição do nível de gás
def simular_leitura_sensor():
    global nivel_gas_atual
    # Diminui o nível de gás por um valor aleatório entre 0.1 e 1.0
    decremento = random.uniform(0.1, 1.0)
    nivel_gas_atual = max(nivel_gas_atual - decremento, 0)  # Garante que o nível não seja menor que 0
    return round(nivel_gas_atual, 2)

# Função para enviar os dados ao servidor
def enviar_dados_servidor(nivel_gas, horario):
    dados = {
        "nivel_gas": nivel_gas,
        "hora": horario.strftime("%H"),  # Hora da leitura
        "minuto": horario.strftime("%M"),  # Minuto da leitura
        "segundo": horario.strftime("%S")  # Segundo da leitura
    }
    try:
        resposta = requests.post(endpoint_url, json=dados)
        if resposta.status_code == 200:
            print(f"Dados enviados com sucesso: {dados}")
        else:
            print(f"Erro ao enviar dados: {resposta.status_code}")
    except Exception as e:
        print(f"Erro de conexão: {e}")

# Loop para simular leituras contínuas do sensor
while nivel_gas_atual > 0:
    nivel_gas = simular_leitura_sensor()
    horario = datetime.now()  # Captura a hora atual da leitura
    enviar_dados_servidor(nivel_gas, horario)
    time.sleep(10)  # Intervalo de 10 segundos entre as leituras
