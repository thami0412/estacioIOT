from flask import Flask, request, jsonify
from flask_cors import CORS
import json

app = Flask(__name__)
CORS(app)  # Habilitar CORS para todas as rotas

# Arquivo para armazenar os dados recebidos e o valor de alerta
arquivo_dados = "dados_nivel_gas.json"
arquivo_parametros = "parametros_alerta.json"

# Função para salvar os dados no arquivo JSON
def salvar_dados(dados):
    try:
        with open(arquivo_dados, "a") as f:
            json.dump(dados, f)
            f.write("\n")
    except Exception as e:
        print(f"Erro ao salvar dados: {e}")

# Função para salvar os parâmetros no arquivo JSON
def salvar_parametros(parametros):
    try:
        with open(arquivo_parametros, "w") as f:
            json.dump(parametros, f)
    except Exception as e:
        print(f"Erro ao salvar parâmetros: {e}")

# Endpoint para receber os dados do sensor
@app.route('/receber_dados', methods=['POST'])
def receber_dados():
    if request.is_json:
        dados = request.get_json()
        salvar_dados(dados)
        return jsonify({"message": "Dados recebidos com sucesso!"}), 200
    else:
        return jsonify({"message": "Dados inválidos!"}), 400

# Endpoint para fornecer os dados ao dashboard
@app.route('/obter_dados', methods=['GET'])
def obter_dados():
    try:
        dados = []
        with open(arquivo_dados, "r") as f:
            for linha in f:
                dados.append(json.loads(linha))
        return jsonify(dados), 200
    except Exception as e:
        return jsonify({"message": f"Erro ao ler os dados: {e}"}), 500

# Endpoint para parametrização de alertas
@app.route('/parametrizar_alerta', methods=['POST'])
def parametrizar_alerta():
    if request.is_json:
        parametros = request.get_json()
        salvar_parametros(parametros)
        return jsonify({"message": "Parâmetro de alerta salvo com sucesso!"}), 200
    else:
        return jsonify({"message": "Dados inválidos!"}), 400

# Endpoint para obter os parâmetros de alerta
@app.route('/obter_parametros_alerta', methods=['GET'])
def obter_parametros_alerta():
    try:
        with open(arquivo_parametros, "r") as f:
            parametros = json.load(f)
        return jsonify(parametros), 200
    except Exception as e:
        return jsonify({"message": f"Erro ao obter os parâmetros: {e}"}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
